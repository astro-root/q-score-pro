import Link from "next/link";
import { Plus, Trophy, Radio } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { EmptyState } from "@/components/ui/EmptyState";
import { LinkButton } from "@/components/ui/Button";
import { ScoreNumber } from "@/components/ui/ScoreNumber";
import { GlowBackdrop } from "@/components/ui/GlowBackdrop";

const STATUS_LABEL: Record<string, string> = {
  DRAFT: "下書き",
  REGISTRATION_OPEN: "エントリー受付中",
  REGISTRATION_CLOSED: "エントリー締切",
  RUNNING: "開催中",
  FINISHED: "終了",
  PUBLISHED: "結果公開",
};

const STATUS_TONE: Record<string, "neutral" | "primary" | "success" | "live"> = {
  DRAFT: "neutral",
  REGISTRATION_OPEN: "primary",
  REGISTRATION_CLOSED: "primary",
  RUNNING: "live",
  FINISHED: "success",
  PUBLISHED: "success",
};

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: memberships } = await supabase
    .from("tournament_members")
    .select("role, tournaments ( id, slug, name, status, updated_at )")
    .eq("user_id", user!.id)
    .order("created_at", { ascending: false });

  const tournaments = (memberships ?? [])
    .map((m) => ({
      role: m.role,
      t: m.tournaments as unknown as {
        id: string;
        slug: string;
        name: string;
        status: string;
        updated_at: string;
      } | null,
    }))
    .filter((x) => x.t !== null)
    .map((x) => ({ role: x.role, t: x.t! }));

  const liveCount = tournaments.filter((x) => x.t.status === "RUNNING").length;

  return (
    <div className="animate-fade-in-up">
      <div className="relative mb-8 overflow-hidden rounded-2xl border border-border bg-panel px-8 py-10">
        <GlowBackdrop />
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.05]"
          style={{
            backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)",
            backgroundSize: "22px 22px",
          }}
        />
        <div className="relative flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-widest text-white/40">
              大会一覧
            </p>
            <h1 className="text-4xl font-extrabold tracking-tight text-white">ようこそ</h1>
            <p className="mt-2 text-sm text-white/50">
              あなたがスタッフとして参加している大会です。
            </p>
          </div>
          <div className="flex items-end gap-8">
            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-white/40">大会数</p>
              <ScoreNumber value={tournaments.length} size="lg" tone="ink" />
            </div>
            <div>
              <p className="mb-1 flex items-center gap-1 text-xs font-medium uppercase tracking-wide text-white/40">
                <Radio className="h-3 w-3" />
                開催中
              </p>
              <ScoreNumber value={liveCount} size="lg" tone="accent" />
            </div>
          </div>
        </div>
        <LinkButton
          href="/tournaments/new"
          icon={<Plus className="h-4 w-4" />}
          className="relative mt-6"
        >
          新しい大会を作成
        </LinkButton>
      </div>

      {tournaments.length === 0 ? (
        <EmptyState
          icon={<Trophy className="h-8 w-8" />}
          title="まだ大会がありません"
          description="「新しい大会を作成」から、最初の大会を立ち上げましょう。"
          action={
            <LinkButton href="/tournaments/new" icon={<Plus className="h-4 w-4" />}>
              新しい大会を作成
            </LinkButton>
          }
        />
      ) : (
        <Card>
          <ul className="divide-y divide-border">
            {tournaments.map(({ role, t }) => (
              <li key={t.id}>
                <Link
                  href={`/tournaments/${t.id}`}
                  className="flex items-center justify-between px-5 py-4 transition hover:bg-surface-muted"
                >
                  <div>
                    <p className="font-medium text-ink">{t.name}</p>
                    <p className="text-xs text-muted">/{t.slug}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge tone={STATUS_TONE[t.status] ?? "neutral"} dot={t.status === "RUNNING"}>
                      {STATUS_LABEL[t.status] ?? t.status}
                    </Badge>
                    <span className="text-xs text-muted">{role}</span>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </Card>
      )}
    </div>
  );
}
