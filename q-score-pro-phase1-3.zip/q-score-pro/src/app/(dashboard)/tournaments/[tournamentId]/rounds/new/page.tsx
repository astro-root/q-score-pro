import { notFound, redirect } from "next/navigation";
import { getTournamentRole } from "@/lib/auth/current-user";
import { can } from "@/lib/permissions";
import { NewRoundForm } from "./new-round-form";

export default async function NewRoundPage({
  params,
}: {
  params: Promise<{ tournamentId: string }>;
}) {
  const { tournamentId } = await params;
  const role = await getTournamentRole(tournamentId);

  if (!role) notFound();
  if (!can(role, "tournament:manage_rounds")) {
    redirect(`/tournaments/${tournamentId}`);
  }

  return (
    <div className="mx-auto max-w-lg">
      <h1 className="mb-6 text-2xl font-bold text-slate-900">ラウンドを作成</h1>
      <div className="rounded-lg border border-slate-200 bg-white p-6">
        <NewRoundForm tournamentId={tournamentId} />
      </div>
    </div>
  );
}
