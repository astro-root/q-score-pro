/**
 * Hand-written Supabase Database types matching
 * supabase/migrations/0001_init.sql.
 *
 * TODO(phase-1-followup): once a live Supabase project exists, replace this
 * file with the generated output of:
 *   supabase gen types typescript --project-id <id> > src/types/database.ts
 * Keep the shape identical so imports elsewhere don't need to change.
 */

export type TournamentStatus =
  | "DRAFT"
  | "REGISTRATION_OPEN"
  | "REGISTRATION_CLOSED"
  | "RUNNING"
  | "FINISHED"
  | "PUBLISHED";

export type TournamentMemberRole =
  | "OWNER"
  | "ADMIN"
  | "QUESTION_MANAGER"
  | "SCORE_OPERATOR"
  | "GRADER"
  | "STREAM_OPERATOR"
  | "VENUE_STAFF"
  | "VIEWER";

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          display_name: string;
          email: string;
          avatar_url: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          display_name: string;
          email: string;
          avatar_url?: string | null;
        };
        Update: Partial<{
          display_name: string;
          avatar_url: string | null;
        }>;
        Relationships: [];
      };
      tournaments: {
        Row: {
          id: string;
          slug: string;
          name: string;
          status: TournamentStatus;
          owner_id: string;
          summary: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          slug: string;
          name: string;
          status?: TournamentStatus;
          owner_id: string;
          summary?: string | null;
        };
        Update: Partial<{
          slug: string;
          name: string;
          status: TournamentStatus;
          summary: string | null;
        }>;
        Relationships: [
          {
            foreignKeyName: "tournaments_owner_id_fkey";
            columns: ["owner_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      tournament_members: {
        Row: {
          id: string;
          tournament_id: string;
          user_id: string;
          role: TournamentMemberRole;
          invited_by: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          tournament_id: string;
          user_id: string;
          role: TournamentMemberRole;
          invited_by?: string | null;
        };
        Update: Partial<{
          role: TournamentMemberRole;
        }>;
        Relationships: [
          {
            foreignKeyName: "tournament_members_tournament_id_fkey";
            columns: ["tournament_id"];
            isOneToOne: false;
            referencedRelation: "tournaments";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "tournament_members_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
    };
    Views: Record<string, never>;
    Functions: {
      is_tournament_member: {
        Args: { p_tournament_id: string };
        Returns: boolean;
      };
      is_tournament_admin: {
        Args: { p_tournament_id: string };
        Returns: boolean;
      };
      has_tournament_role: {
        Args: { p_tournament_id: string; p_roles: TournamentMemberRole[] };
        Returns: boolean;
      };
    };
  };
}
