"use client";

import { useActionState } from "react";
import Link from "next/link";
import { signIn } from "@/lib/auth/actions";
import { Button } from "@/components/ui/Button";
import { Input, Label } from "@/components/ui/Input";

export function LoginForm() {
  const [state, formAction, pending] = useActionState(signIn, null);

  return (
    <form action={formAction} className="flex flex-col gap-4">
      <div className="flex flex-col gap-1.5">
        <Label htmlFor="email">メールアドレス</Label>
        <Input id="email" name="email" type="email" required autoComplete="email" />
        {state?.fieldErrors?.email && (
          <p className="text-xs text-danger">{state.fieldErrors.email[0]}</p>
        )}
      </div>

      <div className="flex flex-col gap-1.5">
        <Label htmlFor="password">パスワード</Label>
        <Input id="password" name="password" type="password" required autoComplete="current-password" />
        {state?.fieldErrors?.password && (
          <p className="text-xs text-danger">{state.fieldErrors.password[0]}</p>
        )}
      </div>

      {state?.error && <p className="text-sm text-danger">{state.error}</p>}

      <Button type="submit" disabled={pending} className="mt-2 w-full">
        {pending ? "ログイン中..." : "ログイン"}
      </Button>

      <p className="text-center text-sm text-muted">
        アカウントをお持ちでない方は{" "}
        <Link href="/signup" className="font-medium text-primary hover:underline">
          新規登録
        </Link>
      </p>
    </form>
  );
}
