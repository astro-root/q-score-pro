import { AuthShell } from "../auth-shell";
import { SignUpForm } from "./signup-form";

export default function SignUpPage() {
  return (
    <AuthShell title="アカウントを作成" subtitle="無料で今すぐ大会運営を始められます">
      <SignUpForm />
    </AuthShell>
  );
}
