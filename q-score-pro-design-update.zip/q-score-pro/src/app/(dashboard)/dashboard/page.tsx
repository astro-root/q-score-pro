import Link from "next/link";
import { Plus, Trophy } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { EmptyState } from "@/components/ui/EmptyState";
import { LinkButton } from "@/components/ui/Button";

const STATUS_LABEL: Record<string, string> = {
  DRAFT: "下書き",
  REGISTRATION_OPEN: "エントリー受付中",
  REGISTRATION_CLOSED: "エントリー締切",
  RUNNING: "開催中",
  FINISHED: "終了",
  PUBLISHED: "結果公開",
};

const STATUS_TONE: Record<string, "neutral" | "primary" | "success" | "live"> = {
  DRAFT: "neutral",
  REGISTRATION_OPEN: "primary",
  REGISTRATION_CLOSED: "primary",
  RUNNING: "live",
  FINISHED: "success",
  PUBLISHED: "success",
};

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: memberships } = await supabase
    .from("tournament_members")
    .select("role, tournaments ( id, slug, name, status, updated_at )")
    .eq("user_id", user!.id)
    .order("created_at", { ascending: false });

  return (
    <div>
      <PageHeader
        eyebrow="大会一覧"
        title="ようこそ"
        description="あなたがスタッフとして参加している大会です。"
        actions={
          <LinkButton href="/tournaments/new" icon={<Plus className="h-4 w-4" />}>
            新しい大会を作成
          </LinkButton>
        }
      />

      {!memberships || memberships.length === 0 ? (
        <EmptyState
          icon={<Trophy className="h-8 w-8" />}
          title="まだ大会がありません"
          description="「新しい大会を作成」から、最初の大会を立ち上げましょう。"
          action={
            <LinkButton href="/tournaments/new" icon={<Plus className="h-4 w-4" />}>
              新しい大会を作成
            </LinkButton>
          }
        />
      ) : (
        <Card>
          <ul className="divide-y divide-border">
            {memberships.map((m) => {
              const t = m.tournaments as unknown as {
                id: string;
                slug: string;
                name: string;
                status: string;
                updated_at: string;
              } | null;
              if (!t) return null;
              return (
                <li key={t.id}>
                  <Link
                    href={`/tournaments/${t.id}`}
                    className="flex items-center justify-between px-5 py-4 transition hover:bg-surface-muted"
                  >
                    <div>
                      <p className="font-medium text-ink">{t.name}</p>
                      <p className="text-xs text-muted">/{t.slug}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge tone={STATUS_TONE[t.status] ?? "neutral"} dot={t.status === "RUNNING"}>
                        {STATUS_LABEL[t.status] ?? t.status}
                      </Badge>
                      <span className="text-xs text-muted">{m.role}</span>
                    </div>
                  </Link>
                </li>
              );
            })}
          </ul>
        </Card>
      )}
    </div>
  );
}
