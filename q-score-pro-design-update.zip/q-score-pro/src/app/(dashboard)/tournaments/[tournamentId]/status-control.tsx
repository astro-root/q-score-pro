"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";

const NEXT_STATUS: Record<string, string | null> = {
  DRAFT: "REGISTRATION_OPEN",
  REGISTRATION_OPEN: "REGISTRATION_CLOSED",
  REGISTRATION_CLOSED: "RUNNING",
  RUNNING: "FINISHED",
  FINISHED: "PUBLISHED",
  PUBLISHED: null,
};

const STATUS_LABEL: Record<string, string> = {
  DRAFT: "下書き",
  REGISTRATION_OPEN: "エントリー受付中",
  REGISTRATION_CLOSED: "エントリー締切",
  RUNNING: "開催中",
  FINISHED: "終了",
  PUBLISHED: "結果公開",
};

export function StatusControl({
  tournamentId,
  currentStatus,
}: {
  tournamentId: string;
  currentStatus: string;
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  const next = NEXT_STATUS[currentStatus];

  function advance() {
    if (!next) return;
    setError(null);
    startTransition(async () => {
      const res = await fetch(`/api/tournaments/${tournamentId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: next }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        setError(body.message ?? "ステータスの更新に失敗しました");
        return;
      }
      router.refresh();
    });
  }

  return (
    <div>
      <p className="mb-3 text-sm text-body">現在: {STATUS_LABEL[currentStatus]}</p>
      {next ? (
        <Button onClick={advance} disabled={pending} variant="secondary" size="sm">
          {pending ? "更新中..." : `${STATUS_LABEL[next]} に進める`}
        </Button>
      ) : (
        <p className="text-sm text-muted">これ以上進める状態はありません</p>
      )}
      {error && <p className="mt-2 text-sm text-danger">{error}</p>}
    </div>
  );
}
