import { notFound } from "next/navigation";
import {
  FileText,
  ClipboardList,
  Users,
  UserCheck,
  ListOrdered,
  ScrollText,
  ShieldCheck,
  LayoutTemplate,
} from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { getTournamentRole } from "@/lib/auth/current-user";
import { can } from "@/lib/permissions";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { StatusControl } from "./status-control";
import { SectionCard } from "./section-card";

const STATUS_LABEL: Record<string, string> = {
  DRAFT: "下書き",
  REGISTRATION_OPEN: "エントリー受付中",
  REGISTRATION_CLOSED: "エントリー締切",
  RUNNING: "開催中",
  FINISHED: "終了",
  PUBLISHED: "結果公開",
};

const STATUS_TONE: Record<string, "neutral" | "primary" | "success" | "live"> = {
  DRAFT: "neutral",
  REGISTRATION_OPEN: "primary",
  REGISTRATION_CLOSED: "primary",
  RUNNING: "live",
  FINISHED: "success",
  PUBLISHED: "success",
};

export default async function TournamentDashboardPage({
  params,
}: {
  params: Promise<{ tournamentId: string }>;
}) {
  const { tournamentId } = await params;
  const supabase = await createClient();

  const { data: tournament } = await supabase
    .from("tournaments")
    .select("id, name, slug, status, summary, created_at")
    .eq("id", tournamentId)
    .maybeSingle();

  if (!tournament) notFound();

  const role = await getTournamentRole(tournamentId);

  return (
    <div>
      <PageHeader
        eyebrow={`/${tournament.slug}`}
        title={tournament.name}
        actions={
          <Badge tone={STATUS_TONE[tournament.status] ?? "neutral"} dot={tournament.status === "RUNNING"}>
            {STATUS_LABEL[tournament.status] ?? tournament.status}
          </Badge>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2">
        <Card className="p-5">
          <h2 className="mb-2 text-sm font-semibold text-ink">大会情報</h2>
          <p className="text-sm text-body">{tournament.summary || "概要はまだ設定されていません。"}</p>
        </Card>

        <Card className="p-5">
          <h2 className="mb-2 text-sm font-semibold text-ink">あなたの権限</h2>
          <p className="text-sm text-body">{role ?? "権限なし"}</p>
        </Card>

        {can(role, "tournament:manage_cms") && (
          <SectionCard
            icon={<FileText className="h-4 w-4" />}
            title="大会ページ・公開情報"
            links={[
              { href: `/tournaments/${tournament.id}/cms`, label: "大会ページ編集" },
              { href: `/tournaments/${tournament.id}/announcements`, label: "お知らせ管理" },
              { href: `/tournaments/${tournament.id}/schedule`, label: "スケジュール管理" },
              { href: `/tournaments/${tournament.id}/entry-fields`, label: "エントリーフォーム項目設定" },
              { href: `/tournaments/${tournament.id}/layouts`, label: "得点表示画面レイアウト編集" },
              { href: `/t/${tournament.slug}`, label: "公開ページを見る", external: true },
            ]}
          />
        )}

        {can(role, "tournament:manage_entries") && (
          <SectionCard
            icon={<ClipboardList className="h-4 w-4" />}
            title="エントリー管理"
            links={[
              { href: `/tournaments/${tournament.id}/entries`, label: "エントリー一覧・CSVエクスポート" },
            ]}
          />
        )}

        {can(role, "tournament:manage_participants") && (
          <SectionCard
            icon={<UserCheck className="h-4 w-4" />}
            title="参加者管理"
            links={[
              { href: `/tournaments/${tournament.id}/participants`, label: "参加者一覧・エントリーからの取り込み" },
            ]}
          />
        )}

        {can(role, "tournament:view") && (
          <SectionCard
            icon={<ListOrdered className="h-4 w-4" />}
            title="ラウンド・得点"
            links={[
              { href: `/tournaments/${tournament.id}/rounds`, label: "ラウンド管理・ペーパークイズ採点・組分け" },
              ...(can(role, "tournament:manage_rounds")
                ? [{ href: `/tournaments/${tournament.id}/stages`, label: "ステージ管理" }]
                : []),
            ]}
          />
        )}

        {can(role, "tournament:view_audit_log") && (
          <SectionCard
            icon={<ScrollText className="h-4 w-4" />}
            title="監査ログ・バックアップ"
            links={[
              { href: `/tournaments/${tournament.id}/audit-log`, label: "監査ログを確認" },
              { href: `/api/tournaments/${tournament.id}/export`, label: "大会データをエクスポート(JSON)", external: true },
            ]}
          />
        )}

        {can(role, "tournament:manage_staff") && (
          <SectionCard
            icon={<Users className="h-4 w-4" />}
            title="スタッフ管理"
            links={[{ href: `/tournaments/${tournament.id}/members`, label: "スタッフ一覧・招待へ" }]}
          />
        )}

        {can(role, "tournament:publish") && (
          <Card className="p-5">
            <div className="mb-3 flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-soft text-primary">
                <ShieldCheck className="h-4 w-4" />
              </span>
              <h2 className="text-sm font-semibold text-ink">大会ステータス</h2>
            </div>
            <StatusControl tournamentId={tournament.id} currentStatus={tournament.status} />
          </Card>
        )}
      </div>

      <div className="mt-8 flex items-start gap-3 rounded-xl border border-dashed border-border-strong bg-surface-muted p-5 text-sm text-muted">
        <LayoutTemplate className="mt-0.5 h-4 w-4 shrink-0" />
        <p>自動テスト・負荷検証・UX改善などは Phase 9 で継続して取り組みます。</p>
      </div>
    </div>
  );
}
