import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { NewTournamentForm } from "./new-tournament-form";

export default function NewTournamentPage() {
  return (
    <div className="mx-auto max-w-lg">
      <PageHeader title="新しい大会を作成" />
      <Card className="p-6">
        <NewTournamentForm />
      </Card>
    </div>
  );
}
