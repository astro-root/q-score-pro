"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { Input, Label, Textarea } from "@/components/ui/Input";

function slugify(input: string) {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 50);
}

export function NewTournamentForm() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [slugTouched, setSlugTouched] = useState(false);
  const [summary, setSummary] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setPending(true);
    setError(null);

    const res = await fetch("/api/tournaments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, slug, summary: summary || undefined }),
    });

    const body = await res.json();
    setPending(false);

    if (!res.ok) {
      setError(body.error === "invalid_input" ? "入力内容を確認してください" : (body.message ?? body.error));
      return;
    }

    router.push(`/tournaments/${body.tournament.id}`);
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <div className="flex flex-col gap-1.5">
        <Label>大会名</Label>
        <Input
          value={name}
          onChange={(e) => {
            setName(e.target.value);
            if (!slugTouched) setSlug(slugify(e.target.value));
          }}
          required
          placeholder="第1回 サンプルオープン"
        />
      </div>

      <div className="flex flex-col gap-1.5">
        <Label>URLスラッグ</Label>
        <Input
          value={slug}
          onChange={(e) => {
            setSlugTouched(true);
            setSlug(slugify(e.target.value));
          }}
          required
          className="font-mono"
          placeholder="sample-open-1"
        />
        <p className="text-xs text-muted">公開ページのURLに使われます(半角英数字とハイフン)</p>
      </div>

      <div className="flex flex-col gap-1.5">
        <Label>大会概要(任意)</Label>
        <Textarea value={summary} onChange={(e) => setSummary(e.target.value)} rows={3} />
      </div>

      {error && <p className="text-sm text-danger">{error}</p>}

      <Button type="submit" disabled={pending} className="mt-2">
        {pending ? "作成中..." : "大会を作成"}
      </Button>
    </form>
  );
}
