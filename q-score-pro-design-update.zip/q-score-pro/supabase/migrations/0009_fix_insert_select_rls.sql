-- =============================================================================
-- Q-Score Pro : Phase 9 hotfix
-- INSERT ... RETURNING と RLS SELECT ポリシーの不整合を修正
--
-- 背景:
-- PostgRESTは `.insert(...).select()` を使うと INSERT に RETURNING が付与され、
-- その返り値にも通常のSELECT用RLSポリシーが適用される。これにより、
-- 「INSERT自体はWITH CHECKを満たして成功するはずなのに、直後の
-- RETURNINGがSELECTポリシーに阻まれてエラーになる」というケースが
-- 発生していた(自動検証スクリプトで発見)。
--
-- 大会作成直後: 作成者はまだ tournament_members に登録されておらず、
-- かつ大会はDRAFTのため tournaments_select_staff / _select_public の
-- どちらにも該当しなかった。「オーナーは自分の大会を常に見られる」という
-- 自然な権限をRLSポリシーとして追加する。
--
-- (entries側の同種の問題はアプリケーション側で `.select()` を外すことで
-- 対応済み - 匿名ユーザーに entries の読み取り権限を与える必要はそもそも
-- 無いため。)
-- =============================================================================

create policy "tournaments_select_owner"
  on public.tournaments for select
  using (owner_id = auth.uid());
